const pi=3.14;

pi=56
