//let:Block scoped supports only ES6
//var:global scoped or function scoped
for(let i=0;i<10;i++){
    console.log(i)
}
console.log(i)