//comppound assignment
var num1:number = 10
var num2:number = 20

var num3:number = num2

console.log(num3)

num3+=num2
console.log(num3)
