//comppound assignment
var num1 = 10;
var num2 = 20;
var num3 = num2;
console.log(num3);
num3 += num2;
console.log(num3);
