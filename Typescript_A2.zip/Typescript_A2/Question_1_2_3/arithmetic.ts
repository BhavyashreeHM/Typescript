var n1:number=10
var n2:number=20

console.log(n1+n2)
console.log(n1-n2)
console.log(n1*n2)
console.log(n1/n2)
console.log(n1%n2)