var n:number=10
var i=0

while(i<=n){
    console.log(i++)

}