var x:number=10

switch(x){
    case 1:
        console.log("Case 1")
        break
    case 2:
        console.log("Case 2")
        break    
    case 3:
        console.log("Case 3")
        break
    default:
        console.log("Nothing")    
}