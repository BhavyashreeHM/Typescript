// tstExprression?value1;value2
var data=prompt("enter a number")
var num= parseInt(data)
console.log(num%2==0?"Even":"Odd")