//alert
//alert("Welcome to typescript")
//confirm
//confirm("Good evening")
//prompt
var a=prompt("Enter first number")

var b=prompt("Enter 2nd number")
var sum=parseInt(a)+parseInt(b)
//alert("Addition is"+sum)

console.log(sum)
