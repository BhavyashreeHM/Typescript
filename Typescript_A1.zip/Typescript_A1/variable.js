//number
var n1 = 10;
console.log(n1);
//string
var s1 = "All power within you";
var s2 = "All is well";
console.log(s1);
console.log(s2);
//boolean
var b1 = true;
var b2 = false;
console.log(b1);
console.log(b2);
//any type
var a1 = {
    prodcuctId: 1,
    productName: "Iphone",
    productPrice: 10000
};
console.log(a1);
//Homogenious array
var array1 = [10, 20, 30, 40];
console.log(array1);
console.log(array1[2]);
console.log(array1.length);
var array2 = ["Bhavya", "acchu"];
console.log(array2);
console.log(array2[1]);
//heterogenous array
var array3 = [10, "bhavya", 'r'];
console.log(array3);
var ar = [10, 20, 30, 40];
console.log(ar);
alert("Welcome to typescript");
